package com.beadout.bot;

import java.util.*;

/** Image-derived geometry. No level number or screen coordinates are supplied by the user. */
public final class AutoLayout {
    public static final class Detection {
        public final Config config;
        public final String summary,signature;
        Detection(Config c,String summary,String signature){config=c;this.summary=summary;this.signature=signature;}
    }
    private static final class Region {
        int id,x,y,w,h,area,tag;long sx,sy;
        double cx(){return (double)sx/area;}double cy(){return (double)sy/area;}
    }
    private static final class Components {
        int[]labels;ArrayList<Region>regions=new ArrayList<>();
    }
    private static final class Box {
        Region r;boolean empty;double x,y;
        Box(Region r,boolean empty){this.r=r;this.empty=empty;x=r.x+r.w*.5;y=r.y+(empty?r.h*.5:Math.min(r.h*.68,r.w*.75));}
    }
    private static final class Grid {
        final Capture.Frame frame;final int w,h,n;final int[]rgb,lum,sat,value;final int bg,bgLum;
        Grid(Capture.Frame f){frame=f;w=(f.width+1)/2;h=(f.height+1)/2;n=w*h;rgb=new int[n];lum=new int[n];sat=new int[n];value=new int[n];int[]hist=new int[32768];
            for(int y=0;y<h;y++)for(int x=0;x<w;x++){
                int c=f.pixel(x*2,y*2),r=(c>>16)&255,g=(c>>8)&255,b=c&255,i=y*w+x;
                rgb[i]=c;lum[i]=(3*r+6*g+b)/10;int max=Math.max(r,Math.max(g,b)),min=Math.min(r,Math.min(g,b));value[i]=max;sat[i]=max==0?0:(max-min)*255/max;
                if(x>w*.1&&x<w*.9&&y>h*.1&&y<h*.9)hist[(r/8)*1024+(g/8)*32+b/8]++;
            }
            int bin=0;for(int i=1;i<hist.length;i++)if(hist[i]>hist[bin])bin=i;
            int r=(bin/1024)*8+4,g=(bin/32%32)*8+4,b=(bin%32)*8+4;bg=0xff000000|r<<16|g<<8|b;bgLum=(3*r+6*g+b)/10;
        }
        boolean color(int i){return (sat[i]>130&&value[i]>90)||(lum[i]>bgLum+15&&sat[i]<60);}
        int at(double x,double y){return Math.max(0,Math.min(h-1,(int)Math.round(y)))*w+Math.max(0,Math.min(w-1,(int)Math.round(x)));}
    }
    public Detection detect(Capture.Frame frame){
        Grid g=new Grid(frame);ArrayList<Box>candidates=slotCandidates(g);List<List<Box>>quads=quads(candidates,g);
        if(quads.isEmpty())throw new IllegalStateException("Looking for the four holding slots");
        String failure="Looking for a closed track";
        for(List<Box>quad:quads){
            try{return build(g,quad);}catch(IllegalStateException e){failure=e.getMessage();}
        }
        throw new IllegalStateException(failure);
    }
    private Detection build(Grid g,List<Box>quad){
        double slotY=0;for(Box b:quad)slotY+=b.y/4;
        int bottom=(int)(slotY-g.h*.055);if(bottom<g.h*.2)throw new IllegalStateException("Waiting for a clear game board");
        byte[]mask=new byte[g.n];
        for(int y=(int)(g.h*.055);y<bottom;y++)for(int x=0;x<g.w;x++){int i=y*g.w+x;if(g.lum[i]<g.bgLum-35||g.color(i))mask[i]=1;}
        mask=close(mask,g.w,g.h);Components all=components(mask,g.w,g.h,false);Region largest=largest(all);
        if(largest==null||largest.area<g.n*.015)throw new IllegalStateException("Track is not visible yet");
        byte[]track=new byte[g.n];for(int i=0;i<g.n;i++)if(all.labels[i]==largest.id)track[i]=1;
        byte[]inverse=new byte[g.n];for(int i=0;i<g.n;i++)inverse[i]=(byte)(1-track[i]);
        Components holes=components(inverse,g.w,g.h,false);Region hole=null;
        for(Region r:holes.regions)if(r.x>0&&r.y>g.h*.055&&r.x+r.w<g.w&&r.y+r.h<bottom&&r.area>g.n*.0015&&(hole==null||r.area>hole.area))hole=r;
        if(hole==null)throw new IllegalStateException("Looking for the loop's inner opening");
        byte[]hm=new byte[g.n];for(int i=0;i<g.n;i++)if(holes.labels[i]==hole.id)hm[i]=1;
        ArrayList<float[]>boundary=contour(hm,g.w,g.h);if(boundary.size()<40)throw new IllegalStateException("Loop outline is incomplete");
        boundary=smooth(boundary,5);ensureClockwise(boundary);
        double[]offset=new double[boundary.size()],bandWidth=new double[boundary.size()];ArrayList<Double>valid=new ArrayList<>(),widths=new ArrayList<>();
        Arrays.fill(offset,Double.NaN);
        for(int i=0;i<boundary.size();i++){
            float[]p=boundary.get(i),a=boundary.get((i+boundary.size()-6)%boundary.size()),b=boundary.get((i+6)%boundary.size());
            double dx=b[0]-a[0],dy=b[1]-a[1],norm=Math.hypot(dx,dy);if(norm<.1)continue;double nx=dy/norm,ny=-dx/norm;
            int first=-1,last=-1,gap=0;
            for(int t=1;t<g.w*.45;t++){
                double x=p[0]+nx*t,y=p[1]+ny*t;boolean colored=x>=0&&x<g.w&&y>=0&&y<g.h&&g.color(g.at(x,y));
                if(colored){if(first<0)first=t;last=t;gap=0;}else if(first>=0&&++gap>1)break;
            }
            if(first>=0&&last-first>g.w*.022){offset[i]=(first+last)/2.0;bandWidth[i]=last-first;valid.add(offset[i]);widths.add(bandWidth[i]);}
        }
        if(valid.size()<boundary.size()*.25)throw new IllegalStateException("Loop is obscured; waiting for a clear frame");
        double median=median(valid),width=median(widths);ArrayList<float[]>loop=new ArrayList<>();
        for(int i=0;i<boundary.size();i++){
            float[]p=boundary.get(i),a=boundary.get((i+boundary.size()-6)%boundary.size()),b=boundary.get((i+6)%boundary.size());
            double dx=b[0]-a[0],dy=b[1]-a[1],norm=Math.max(.1,Math.hypot(dx,dy));double d=Double.isFinite(offset[i])&&Math.abs(offset[i]-median)<width*.4?offset[i]:median;
            loop.add(new float[]{(float)(p[0]+dy/norm*d),(float)(p[1]-dx/norm*d)});
        }
        loop=smooth(loop,4);ensureClockwise(loop);rotateToPickup(loop,hole.cx());
        double minX=Double.POSITIVE_INFINITY,maxX=0;for(float[]p:loop){minX=Math.min(minX,p[0]);maxX=Math.max(maxX,p[0]);}
        if(maxX-minX<g.w*.12)throw new IllegalStateException("Closed loop is too small");
        Config c=new Config();c.clearLevelGeometry();c.automatic=true;c.rowUnit=5;c.requireBorder=true;c.backgroundKnown=true;c.backgroundRgb=g.bg;c.confirmed=true;
        double slotWidth=0;
        for(int i=0;i<4;i++){
            Box b=quad.get(i);c.slots.add(new float[]{(float)(b.x/g.w),(float)(b.y/g.h)});slotWidth+=b.r.w/4.0;
            int color=b.empty?g.rgb[g.at(b.x,b.y)]:mixWhite(g.bg,.45);c.emptySlotRgb[i]=color;c.emptySlotKnown[i]=true;
        }
        c.slotLift=slotWidth*.4/g.h;
        ArrayList<float[]>normalized=normalize(loop,g.w,g.h);c.lanes.add(normalized);
        byte[]beads=new byte[g.n];for(int y=(int)(g.h*.11);y<bottom;y++)for(int x=0;x<g.w;x++){int i=y*g.w+x;if(g.color(i))beads[i]=1;}
        beads=close(beads,g.w,g.h);
        ArrayList<Double>pitches=new ArrayList<>();
        for(int side=0;side<2;side++){
            byte[]sideMask=beads.clone();double limit=side==0?minX-width*.55:maxX+width*.55;
            for(int y=0;y<g.h;y++)for(int x=0;x<g.w;x++)if(side==0?x>limit:x<limit)sideMask[y*g.w+x]=0;
            Components bodies=components(sideMask,g.w,g.h,true);Region body=largest(bodies);
            ArrayList<float[]>feed;
            if(body!=null&&body.area>g.w*g.w*.008){
                byte[]shape=new byte[g.n];for(int i=0;i<g.n;i++)if(bodies.labels[i]==body.id)shape[i]=1;
                byte[]sk=thin(shape,g.w,g.h);ArrayList<Integer>nodes=new ArrayList<>();for(int i=0;i<g.n;i++)if(sk[i]!=0)nodes.add(i);
                double headX=0,headN=0;for(int y=body.y;y<Math.min(body.y+12,body.y+body.h);y++)for(int x=body.x;x<body.x+body.w;x++)if(shape[y*g.w+x]!=0){headX+=x;headN++;}
                headX=headN>0?headX/headN:body.cx();double headY=body.y+2;
                int head=-1,toe=-1;double headD=Double.POSITIVE_INFINITY,toeD=Double.POSITIVE_INFINITY;int joinIndex=0;
                for(int node:nodes){int x=node%g.w,y=node/g.w;double d=Math.hypot(x-headX,y-headY);if(d<headD){headD=d;head=node;}
                    for(int j=0;j<loop.size();j+=3){float[]p=loop.get(j);double dd=Math.hypot(x-p[0],y-p[1]);if(dd<toeD){toeD=dd;toe=node;joinIndex=j;}}
                }
                if(head<0||toe<0)throw new IllegalStateException("Queue centerline is incomplete");
                ArrayList<float[]>route=route(sk,g.w,g.h,toe,head);if(route.size()<5)throw new IllegalStateException("Queue is too short to identify");
                route=smoothOpen(route,3);feed=new ArrayList<>();feed.add(loop.get(joinIndex));feed.addAll(route);
                double pitch=measurePitch(g.frame,headX*2,(body.y+3)*2,slotWidth*2);
                if(pitch>0)pitches.add(pitch);
            }else{
                int j=0;for(int i=1;i<loop.size();i++)if(side==0?loop.get(i)[0]<loop.get(j)[0]:loop.get(i)[0]>loop.get(j)[0])j=i;
                float[]p=loop.get(j);feed=new ArrayList<>();feed.add(p);feed.add(new float[]{(float)(g.w*(side==0?.1:.9)),p[1]});feed.add(new float[]{(float)(g.w*(side==0?.1:.9)),(float)(g.h*.12)});
            }
            Config.FeedPath fp=new Config.FeedPath(0,normalize(feed,g.w,g.h));fp.skipConnector=true;c.feeders.add(fp);
        }
        c.pitch=pitches.isEmpty()?slotWidth*2*.12:median(pitches);c.pitch=Math.max(4,Math.min(18,c.pitch));
        c.loopRows=Math.max(20,Math.min(400,(int)Math.round(new PathGeometry(c.lanes.get(0),true,g.frame.width,g.frame.height).length/c.pitch)));
        refreshSquares(g,c,slotY);
        if(c.buttons.isEmpty())throw new IllegalStateException("No selectable squares are visible");
        String sig=Math.round(slotY/3)+":"+Math.round(hole.x/3)+":"+Math.round(hole.y/3)+":"+Math.round(hole.w/3)+":"+Math.round(hole.h/3);
        return new Detection(c,"Found 4 slots, "+c.buttons.size()+" squares, a loop and 2 feeder queues",sig);
    }
    public void refreshSquares(Capture.Frame f,Config c){Grid g=new Grid(f);double y=0;for(float[]p:c.slots)y+=p[1]*g.h/4;refreshSquares(g,c,y);}
    private static void refreshSquares(Grid g,Config c,double slotY){
        byte[]m=new byte[g.n];for(int y=(int)(slotY+g.w*.055);y<g.h*.9;y++)for(int x=0;x<g.w;x++){int i=y*g.w+x;if((g.sat[i]>110&&g.value[i]>90)||(g.lum[i]>g.bgLum+18&&g.sat[i]<50)||(g.sat[i]<110&&g.value[i]<180&&g.lum[i]<g.bgLum-45))m[i]=1;}
        m=colorClasses(g,m);Components cc=components(m,g.w,g.h,true,true);ArrayList<Region>boxes=new ArrayList<>();
        for(Region r:cc.regions)if(r.w>=g.w*.055&&r.w<=g.w*.20&&r.h>=g.w*.045&&r.h<=g.w*.25&&r.area>(double)r.w*r.h*.3)boxes.add(r);
        boxes.sort(Comparator.comparingInt((Region r)->Math.round(r.y/(float)(g.w*.06))).thenComparingInt(r->r.x));
        c.buttons.clear();c.clickable=new boolean[boxes.size()];c.unknownBoxes=new boolean[boxes.size()];c.unlockValues=new int[boxes.size()];
        byte[]walls=wallMask(g,boxes,slotY);
        for(int i=0;i<boxes.size();i++){Region r=boxes.get(i);c.buttons.add(new float[]{(float)((r.x+r.w*.5)/g.w),(float)((r.y+Math.min(r.h*.45,r.w*.45))/g.h)});
            c.unknownBoxes[i]=r.tag==16;
            boolean raised=r.h>=r.w*.98;
            c.clickable[i]=!c.unknownBoxes[i]&&raised&&escape(g,walls,boxes,i,-1,slotY);
        }
        for(int i=0;i<boxes.size();i++)if(c.clickable[i])for(int j=0;j<boxes.size();j++)if(i!=j&&!c.clickable[j]&&escape(g,walls,boxes,j,i,slotY))c.unlockValues[i]+=c.unknownBoxes[j]?2:1;
    }
    private static ArrayList<Box>slotCandidates(Grid g){
        byte[]bright=new byte[g.n],colored=new byte[g.n];
        for(int y=(int)(g.h*.30);y<g.h*.86;y++)for(int x=0;x<g.w;x++){
            int i=y*g.w+x,r=(g.rgb[i]>>16)&255,gg=(g.rgb[i]>>8)&255,b=g.rgb[i]&255,br=(g.bg>>16)&255,bg=(g.bg>>8)&255,bb=g.bg&255;
            if(g.lum[i]>g.bgLum+8&&g.sat[i]<110&&(r-br)*(r-br)+(gg-bg)*(gg-bg)+(b-bb)*(b-bb)>144)bright[i]=1;
            if((g.sat[i]>110&&g.value[i]>90)||(g.lum[i]>g.bgLum+18&&g.sat[i]<50))colored[i]=1;
        }
        ArrayList<Box>out=new ArrayList<>();
        for(Region r:components(bright,g.w,g.h,true).regions)if(r.w>g.w*.045&&r.w<g.w*.19&&r.h>g.w*.035&&r.h<g.w*.17&&(double)r.w/r.h>1.05&&(double)r.w/r.h<1.8&&r.area>(double)r.w*r.h*.45)out.add(new Box(r,true));
        for(Region r:components(colorClasses(g,colored),g.w,g.h,true,true).regions)if(r.w>g.w*.055&&r.w<g.w*.19&&r.h>r.w*.5&&r.h<r.w*1.75&&r.area>(double)r.w*r.h*.35){Box b=new Box(r,false);boolean duplicate=false;for(Box old:out)if(Math.hypot(old.x-b.x,old.y-b.y)<r.w*.5){duplicate=true;break;}if(!duplicate)out.add(b);}
        return out;
    }
    private static List<List<Box>>quads(ArrayList<Box>boxes,Grid g){
        ArrayList<List<Box>>out=new ArrayList<>();
        for(Box seed:boxes){ArrayList<Box>row=new ArrayList<>();for(Box b:boxes)if(Math.abs(b.y-seed.y)<g.w*.025&&b.y<g.h*.82)row.add(b);row.sort(Comparator.comparingDouble(b->b.x));
            for(int i=0;i+3<row.size();i++){
                List<Box>q=new ArrayList<>(row.subList(i,i+4));double d=(q.get(3).x-q.get(0).x)/3,center=(q.get(0).x+q.get(3).x)/2;
                if(d<g.w*.09||d>g.w*.2||Math.abs(center-g.w*.5)>g.w*.09)continue;
                boolean good=true;for(int j=0;j<3;j++)if(Math.abs((q.get(j+1).x-q.get(j).x)-d)>d*.22)good=false;
                if(good)out.add(q);
            }
        }out.sort(Comparator.comparingDouble(q->q.get(0).y));return out;
    }
    private static int mixWhite(int c,double a){int r=(int)(((c>>16)&255)*(1-a)+255*a),g=(int)(((c>>8)&255)*(1-a)+255*a),b=(int)((c&255)*(1-a)+255*a);return 0xff000000|r<<16|g<<8|b;}
    private static double measurePitch(Capture.Frame f,double x,double y,double boxWidth){
        int count=(int)Math.min(130,f.height-y-2);if(count<35)return -1;double bestScore=-1,bestPeriod=-1;
        for(int offset:new int[]{-4,0,4}){
            double[]v=new double[count],r=new double[count];for(int i=0;i<count;i++){int p=f.pixel((int)x+offset,(int)y+i);v[i]=Math.max((p>>16)&255,Math.max((p>>8)&255,p&255));}
            for(int i=0;i<count;i++){double mean=0;int n=0;for(int j=Math.max(0,i-8);j<=Math.min(count-1,i+8);j++){mean+=v[j];n++;}r[i]=v[i]-mean/n;}
            int lo=Math.max(4,(int)(boxWidth*.07)),hi=Math.min(16,(int)(boxWidth*.19));double[]scores=new double[hi+2];Arrays.fill(scores,-1);
            for(int lag=lo;lag<=hi;lag++){double a=0,b=0,ab=0;for(int i=0;i<count-lag;i++){a+=r[i]*r[i];b+=r[i+lag]*r[i+lag];ab+=r[i]*r[i+lag];}scores[lag]=ab/Math.max(1e-6,Math.sqrt(a*b));}
            for(int lag=lo;lag<=hi;lag++)if(scores[lag]>bestScore){bestScore=scores[lag];double delta=0;if(lag>lo&&lag<hi){double denom=scores[lag-1]-2*scores[lag]+scores[lag+1];if(Math.abs(denom)>1e-6)delta=Math.max(-.5,Math.min(.5,.5*(scores[lag-1]-scores[lag+1])/denom));}bestPeriod=lag+delta;}
        }return bestScore>.25?bestPeriod:-1;
    }
    private static double median(List<Double>a){ArrayList<Double>b=new ArrayList<>(a);Collections.sort(b);return b.get(b.size()/2);}
    private static Region largest(Components c){Region best=null;for(Region r:c.regions)if(best==null||r.area>best.area)best=r;return best;}
    private static Components components(byte[]m,int w,int h,boolean eight){
        return components(m,w,h,eight,false);
    }
    private static Components components(byte[]m,int w,int h,boolean eight,boolean sameClass){
        Components c=new Components();c.labels=new int[m.length];int[]q=new int[m.length];int label=0;
        for(int start=0;start<m.length;start++)if(m[start]!=0&&c.labels[start]==0){Region r=new Region();r.id=++label;r.tag=m[start];r.x=w;r.y=h;int maxX=0,maxY=0,head=0,tail=0;q[tail++]=start;c.labels[start]=label;
            while(head<tail){int i=q[head++],x=i%w,y=i/w;r.area++;r.sx+=x;r.sy+=y;r.x=Math.min(r.x,x);r.y=Math.min(r.y,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){if(dx==0&&dy==0||!eight&&dx!=0&&dy!=0)continue;int xx=x+dx,yy=y+dy;if(xx<0||xx>=w||yy<0||yy>=h)continue;int k=yy*w+xx;if(m[k]!=0&&c.labels[k]==0&&(!sameClass||m[k]==m[i])){c.labels[k]=label;q[tail++]=k;}}
            }r.w=maxX-r.x+1;r.h=maxY-r.y+1;c.regions.add(r);
        }return c;
    }
    private static byte[]colorClasses(Grid g,byte[]m){
        byte[]out=new byte[m.length];for(int i=0;i<m.length;i++)if(m[i]!=0){if(g.sat[i]<110&&g.value[i]<180&&g.lum[i]<g.bgLum-45){out[i]=16;continue;}if(g.sat[i]<80){out[i]=15;continue;}
            int c=g.rgb[i];double r=(c>>16)&255,gg=(c>>8)&255,b=c&255,max=Math.max(r,Math.max(gg,b)),min=Math.min(r,Math.min(gg,b)),d=max-min,h=0;
            if(d>0){if(max==r)h=60*((gg-b)/d%6);else if(max==gg)h=60*((b-r)/d+2);else h=60*((r-gg)/d+4);}if(h<0)h+=360;
            out[i]=(byte)(h<16||h>344?1:h<44?2:h<72?3:h<160?4:h<206?5:h<256?6:h<316?7:8);
        }return out;
    }
    private static byte[]wallMask(Grid g,List<Region>boxes,double slotY){
        byte[]wall=new byte[g.n];int br=(g.bg>>16)&255,bg=(g.bg>>8)&255;
        for(int y=(int)slotY;y<g.h*.93;y++)for(int x=0;x<g.w;x++){int i=y*g.w+x,c=g.rgb[i],r=(c>>16)&255,gg=(c>>8)&255,b=c&255;
            if(b>r+25&&b>gg+12&&r<br-8&&gg<bg-6&&g.lum[i]<g.bgLum-10)wall[i]=1;
        }
        for(Region r:boxes)for(int y=Math.max(0,r.y-1);y<Math.min(g.h,r.y+r.h+1);y++)for(int x=Math.max(0,r.x-1);x<Math.min(g.w,r.x+r.w+1);x++)wall[y*g.w+x]=0;
        return wall;
    }
    private static boolean escape(Grid g,byte[]walls,List<Region>boxes,int candidate,int removed,double slotY){
        Region own=boxes.get(candidate);int minY=Math.max(1,(int)(slotY+g.w*.01)),maxY=Math.min(g.h-2,(int)(g.h*.92));
        int width=g.w,height=maxY-minY+1;if(height<=0)return false;byte[]occupied=new byte[width*height];
        for(int y=minY;y<=maxY;y++)System.arraycopy(walls,y*width,occupied,(y-minY)*width,width);
        for(int i=0;i<boxes.size();i++)if(i!=candidate&&i!=removed){Region r=boxes.get(i);int bh=Math.min(r.h,(int)Math.round(r.w*.8)),top=r.y+r.h-bh;
            for(int y=Math.max(top,minY);y<Math.min(r.y+r.h,maxY+1);y++)for(int x=Math.max(0,r.x);x<Math.min(width,r.x+r.w);x++)occupied[(y-minY)*width+x]=1;
        }
        int stride=width+1;int[]sum=new int[stride*(height+1)];for(int y=0;y<height;y++){int run=0;for(int x=0;x<width;x++){run+=occupied[y*width+x];sum[(y+1)*stride+x+1]=sum[y*stride+x+1]+run;}}
        int hw=Math.max(2,(int)(own.w*.43)),hh=Math.max(2,(int)(own.w*.34));int startX=(int)Math.round(own.x+own.w*.5),startY=(int)Math.round(own.y+own.h-own.w*.4)-minY;
        int target=(int)(slotY+g.w*.075)-minY;startY=Math.max(hh,Math.min(height-hh-1,startY));
        int[]queue=new int[occupied.length];byte[]seen=new byte[occupied.length];int head=0,tail=0,start=startY*width+startX;if(start<0||start>=seen.length)return false;queue[tail++]=start;seen[start]=1;
        while(head<tail){int at=queue[head++],x=at%width,y=at/width;if(y<=target)return true;
            for(int dir=0;dir<4;dir++){int xx=x+(dir==0?-1:dir==1?1:0),yy=y+(dir==2?-1:dir==3?1:0);if(xx<hw||xx>=width-hw||yy<hh||yy>=height-hh)continue;int id=yy*width+xx;if(seen[id]!=0)continue;
                int l=xx-hw,r=xx+hw+1,t=yy-hh,b=yy+hh+1;int count=sum[b*stride+r]-sum[t*stride+r]-sum[b*stride+l]+sum[t*stride+l];if(count!=0)continue;seen[id]=1;queue[tail++]=id;
            }
        }return false;
    }
    private static byte[]morph(byte[]m,int w,int h,boolean dilate){byte[]out=new byte[m.length];for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){boolean v=!dilate;outer:for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)if((m[(y+dy)*w+x+dx]!=0)==dilate){v=dilate;break outer;}if(v)out[y*w+x]=1;}return out;}
    private static byte[]close(byte[]m,int w,int h){return morph(morph(m,w,h,true),w,h,false);}
    private static byte[]open(byte[]m,int w,int h){return morph(morph(m,w,h,false),w,h,true);}
    private static ArrayList<float[]>contour(byte[]m,int w,int h){
        int vw=w+1;int[]next=new int[(w+1)*(h+1)];Arrays.fill(next,-1);int start=-1;
        for(int y=0;y<h;y++)for(int x=0;x<w;x++)if(m[y*w+x]!=0){int a=y*vw+x,b=a+1,c=a+vw+1,d=a+vw;
            if(y==0||m[(y-1)*w+x]==0){next[a]=b;if(start<0)start=a;}
            if(x==w-1||m[y*w+x+1]==0)next[b]=c;
            if(y==h-1||m[(y+1)*w+x]==0)next[c]=d;
            if(x==0||m[y*w+x-1]==0)next[d]=a;
        }
        ArrayList<float[]>out=new ArrayList<>();int at=start;for(int i=0;at>=0&&i<10000;i++){out.add(new float[]{at%vw,at/vw});at=next[at];if(at==start)break;}return out;
    }
    private static ArrayList<float[]>smooth(List<float[]>p,int radius){ArrayList<float[]>out=new ArrayList<>();for(int i=0;i<p.size();i++){double x=0,y=0;for(int j=-radius;j<=radius;j++){float[]a=p.get((i+j+p.size())%p.size());x+=a[0];y+=a[1];}out.add(new float[]{(float)(x/(2*radius+1)),(float)(y/(2*radius+1))});}return out;}
    private static ArrayList<float[]>smoothOpen(List<float[]>p,int radius){ArrayList<float[]>out=new ArrayList<>();for(int i=0;i<p.size();i++){double x=0,y=0;int n=0;for(int j=Math.max(0,i-radius);j<=Math.min(p.size()-1,i+radius);j++){x+=p.get(j)[0];y+=p.get(j)[1];n++;}out.add(new float[]{(float)(x/n),(float)(y/n)});}return out;}
    private static void ensureClockwise(ArrayList<float[]>p){double area=0;for(int i=0;i<p.size();i++){float[]a=p.get(i),b=p.get((i+1)%p.size());area+=a[0]*b[1]-a[1]*b[0];}if(area<0)Collections.reverse(p);}
    private static void rotateToPickup(ArrayList<float[]>p,double cx){int best=0;double score=-Double.MAX_VALUE;for(int i=0;i<p.size();i++){float[]a=p.get(i);double v=a[1]-.1*Math.abs(a[0]-cx);if(v>score){score=v;best=i;}}Collections.rotate(p,-best);}
    private static ArrayList<float[]>normalize(List<float[]>p,int w,int h){ArrayList<float[]>out=new ArrayList<>();for(float[]a:p)out.add(new float[]{Math.max(0,Math.min(1,a[0]/w)),Math.max(0,Math.min(1,a[1]/h))});return out;}
    private static byte[]thin(byte[]input,int w,int h){byte[]m=input.clone(),remove=new byte[m.length];for(int iteration=0;iteration<100;iteration++){boolean changed=false;for(int phase=0;phase<2;phase++){
        Arrays.fill(remove,(byte)0);for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x;if(m[i]==0)continue;int[]p={m[i-w],m[i-w+1],m[i+1],m[i+w+1],m[i+w],m[i+w-1],m[i-1],m[i-w-1]};int n=0,t=0;for(int k=0;k<8;k++){n+=p[k];if(p[k]==0&&p[(k+1)%8]!=0)t++;}if(n<2||n>6||t!=1)continue;boolean ok=phase==0?p[0]*p[2]*p[4]==0&&p[2]*p[4]*p[6]==0:p[0]*p[2]*p[6]==0&&p[0]*p[4]*p[6]==0;if(ok)remove[i]=1;}
        for(int i=0;i<m.length;i++)if(remove[i]!=0){m[i]=0;changed=true;}}
        if(!changed)break;
    }return m;}
    private static ArrayList<float[]>route(byte[]m,int w,int h,int start,int end){int[]parent=new int[m.length],q=new int[m.length];Arrays.fill(parent,-2);parent[start]=-1;int head=0,tail=0;q[tail++]=start;
        while(head<tail&&parent[end]==-2){int i=q[head++],x=i%w,y=i/w;for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){if(dx==0&&dy==0)continue;int xx=x+dx,yy=y+dy;if(xx<0||xx>=w||yy<0||yy>=h)continue;int j=yy*w+xx;if(m[j]!=0&&parent[j]==-2){parent[j]=i;q[tail++]=j;}}}
        ArrayList<float[]>out=new ArrayList<>();if(parent[end]==-2)return out;for(int at=end;at>=0;at=parent[at])out.add(new float[]{at%w,at/w});Collections.reverse(out);return out;
    }
}
