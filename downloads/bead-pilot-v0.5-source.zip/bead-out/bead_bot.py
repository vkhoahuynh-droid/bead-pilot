#!/usr/bin/env python3
"""Screenshot-based heuristic player for the supplied Bead Out layout."""
import argparse
import json
import subprocess
import time
from pathlib import Path

import cv2
import numpy as np

# All coordinates refer to the supplied 582 x 1280 screenshot.
DEFAULT = {
    "size": [582, 1280],
    "slots": [[190, 600], [257, 600], [326, 600], [394, 600]],
    "buttons": [[180, 707], [254, 707], [329, 707], [403, 707],
                [180, 800], [254, 800], [329, 800], [403, 800],
                [180, 886], [403, 886], [180, 968], [403, 968],
                [254, 1050], [329, 1050], [403, 1050]],
    "rail": [0, 0, 582, 510],
    "colors_rgb": {"yellow": [245, 227, 0], "white": [236, 231, 232],
                   "lavender": [150, 130, 245], "orange": [255, 85, 5],
                   "green": [0, 163, 7], "blue": [16, 188, 245],
                   "lime": [175, 225, 0], "purple": [133, 0, 146],
                   "pink": [195, 0, 95], "peach": [255, 165, 131],
                   "brown": [174, 88, 16], "olive": [139, 160, 19]},
    "match_distance": 29,
}


def lab(rgb):
    return cv2.cvtColor(np.asarray(rgb, np.uint8).reshape(-1, 1, 3),
                        cv2.COLOR_RGB2LAB).reshape(-1, 3).astype(float)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--serial', help='ADB device serial')
    p.add_argument('--config', type=Path)
    p.add_argument('--write-config', type=Path)
    p.add_argument('--play', action='store_true', help='Enable taps; default is inspection only')
    p.add_argument('--root', action='store_true', help='Run input tap via su -c')
    p.add_argument('--max-active', type=int, choices=range(1, 5), default=3)
    p.add_argument('--interval', type=float, default=0.8)
    p.add_argument('--idle-timeout', type=float, default=45)
    p.add_argument('--seconds', type=float, default=300)
    p.add_argument('--debug', type=Path, help='Optional diagnostic image; no screenshots are saved by default')
    a = p.parse_args()
    if a.write_config:
        a.write_config.write_text(json.dumps(DEFAULT, indent=2) + '\n')
        return
    if min(a.interval, a.idle_timeout, a.seconds) <= 0:
        p.error('Timing values must be positive')
    cfg = json.loads(a.config.read_text()) if a.config else DEFAULT
    adb = ['adb'] + (['-s', a.serial] if a.serial else [])

    def run(*args):
        return subprocess.run(adb + list(args), check=True, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=15).stdout

    names = list(cfg['colors_rgb'])
    palette = lab(list(cfg['colors_rgb'].values()))
    expected_w, expected_h = cfg['size']

    def classify(frame, point):
        x, y = point
        # A patch avoids dependence on a single reflection/highlight pixel.
        patch = frame[max(0, y-7):y+8, max(0, x-7):x+8]
        rgb = np.median(patch.reshape(-1, 3), axis=0)[::-1]
        distances = np.linalg.norm(palette - lab([rgb])[0], axis=1)
        i = int(np.argmin(distances))
        return names[i] if distances[i] < cfg['match_distance'] else None

    def screenshot():
        data = run('exec-out', 'screencap', '-p')
        original = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if original is None:
            raise RuntimeError('Could not decode Android screenshot')
        h, w = original.shape[:2]
        if abs((w / h) / (expected_w / expected_h) - 1) > 0.025:
            raise RuntimeError('Screen aspect ratio differs from reference. Configure coordinates first.')
        return original, cv2.resize(original, (expected_w, expected_h))

    start = last_action = time.monotonic()
    pending = None
    previous_state = None
    stable = 0
    while time.monotonic() - start < a.seconds:
        original, frame = screenshot()
        slots = [classify(frame, pt) for pt in cfg['slots']]
        buttons = [classify(frame, pt) for pt in cfg['buttons']]
        state = (tuple(slots), tuple(buttons))
        stable = stable + 1 if state == previous_state else 0
        previous_state = state
        # Require evidence that an issued tap changed the board or tray.
        if pending:
            before, sent = pending
            if state != before:
                pending = None
            elif time.monotonic() - sent > 5:
                raise RuntimeError('Tap produced no detected state change; stopped to avoid repeated taps')

        x0, y0, x1, y1 = cfg['rail']
        rail = frame[y0:y1:3, x0:x1:3, ::-1]
        pixels = lab(rail.reshape(-1, 3))
        distances = np.linalg.norm(pixels[:, None, :] - palette[None, :, :], axis=2)
        closest = distances.argmin(axis=1)
        counts = {name: int(np.sum((closest == i) &
                  (distances[:, i] < cfg['match_distance']))) for i, name in enumerate(names)}
        active = [color for color in slots if color]
        # Prefer visible bead colors with no competing active collector.
        candidates = [(counts[color] / (1 + 3 * active.count(color)), i, color)
                      for i, color in enumerate(buttons) if color and counts[color] >= 8]
        candidates.sort(reverse=True)
        chosen = candidates[0] if candidates else None
        debug = frame.copy()
        for points, labels in [(cfg['slots'], slots), (cfg['buttons'], buttons)]:
            for (x, y), label in zip(points, labels):
                cv2.circle(debug, (x, y), 13, (0, 0, 255), 2)
                cv2.putText(debug, label or '?', (x-25, y-18),
                            cv2.FONT_HERSHEY_SIMPLEX, .35, (0, 0, 0), 1)
        if a.debug:
            cv2.imwrite(str(a.debug), debug)
        print(f'slots={slots} buttons={buttons} next={chosen}', flush=True)
        if not a.play:
            print('Inspection only. Use --debug PATH to inspect annotations before enabling --play.')
            return
        if stable >= 1 and not pending and len(active) < a.max_active and chosen:
            _, index, color = chosen
            x, y = cfg['buttons'][index]
            h, w = original.shape[:2]
            command = f'input tap {round(x*w/expected_w)} {round(y*h/expected_h)}'
            if a.root:
                run('shell', 'su', '-c', command)
            else:
                run('shell', command)
            last_action = time.monotonic()
            pending = (state, last_action)
            stable = 0
            print(f'Tapped {color} at button {index}', flush=True)
        if time.monotonic() - last_action > a.idle_timeout:
            print('No useful tap for idle timeout; stopped. Inspect the game and debug image.')
            return
        time.sleep(a.interval)
    print('Time limit reached; stopped.')


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nStopped.')
    except (RuntimeError, subprocess.SubprocessError, OSError, ValueError) as exc:
        raise SystemExit(str(exc))
