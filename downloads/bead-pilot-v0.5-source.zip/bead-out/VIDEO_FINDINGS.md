# Findings from the supplied gameplay clip

Source: `VID_20261030_174134_1.mp4`, 9.102 seconds, 388 × 854, 30 fps.
This is a downscaled recording; the user's portrait display is 1440 × 3168.

## Observed directly

- Five beads form each cross-track row. Visible fill changes occur in 5% steps.
- The central loop moves counterclockwise during the clip.
- Matching beads leave at the bottom pickup and travel into an active square.
  The visible fill text can lag those flying particles briefly.
- Removing beads creates a gap. The right feeder refills it first.
- The left feeder remains stationary for the entire recorded interval.
- Red, purple, cyan and royal-blue collectors are active by 3 seconds.
- No square completes, no win screen appears, and no ad appears in this clip.
  Therefore the video does not validate completion or the ad-recovery sequence.

Percentage labels read manually from exact frames:

| Seconds | Red | Purple | Cyan | Royal blue |
| --- | --- | --- | --- | --- |
| 3.0 | 0% | 0% | 0% | 0% |
| 3.5 | 0% | 0% | 15% | 0% |
| 4.0 | 0% | 0% | 35% | 0% |
| 4.5 | 0% | 0% | 50% | 0% |
| 5.0 | 0% | 0% | 50% | 0% |
| 5.5 | 0% | 0% | 50% | 0% |
| 6.0 | 20% | 0% | 50% | 0% |
| 6.5 | 40% | 0% | 50% | 0% |
| 7.0–9.0 | 50% | 0% | 50% | 0% |

The red top edge in the right feeder, at native x=350, stays at y=104 until
4.5 seconds, then moves to y=110 at 5.0, 138 at 5.5, 162 at 6.0,
174 at 7.5, 196 at 8.0, and 220 at 8.5. The corresponding left edge at
x=35 stays at y=98. These positions were measured with an HSV color mask.

## Breaking issue fixed in v0.4

The automatic single-square probe in v0.3 was invalid as a prerequisite for play.
A collector may consume the matching 50-bead block in the loop but be unable to
reach its next matching block until other colors are collected from the loop.
Those other collectors create the gaps needed to advance the feeder queues.

Autoplay now allows multiple distinct collector colors immediately after motion
calibration. It does not wait for a single collector to finish first. After Next
Level, it resumes the same multi-collector strategy instead of re-entering a
single-square probe. The one-square diagnostic remains optional and explicitly
warns that it can stall. Unknown duplicate-color collector priority is excluded
from planned actions rather than intentionally triggering a pause.

## What the regression establishes

The regression models five parallel 100-position lanes, finite left/right queues,
and the visible color ordering. Its junction indices and phase are inferred,
rounded parameters; they are not automatically extracted game state.

It verifies that initially selectable colors can stall individually at 50%,
whereas selecting several colors opens the feeder dependency chain. Its coarse
progress comparison is within one five-bead row of the observed red/cyan labels,
and feeder movement is within one row plus pixel error.

The original simulator regression remains approximate. Version 0.5 additionally replays actual pixels through automatic layout detection and motion tracking: four slots, nine then five squares, one loop, two feeders, and changing reachable squares. Synthetic image edits test a closed wall and an unknown obstacle. This does not establish full-level autoplay.

The host Tesseract experiment misread 50% as 30%. Version 0.5 instead bundles offline ML Kit OCR in the Android application process and checks progress positions, increments, slot generations and timestamps. Native OCR accuracy on the phone remains unverified; host interpretation tests use supplied OCR words and do not substitute for that validation.

The speed estimator also now averages elapsed time and total row displacement
over several observations. This prevents alternating one-row/two-row shifts at
a 200 ms capture cadence from repeatedly resetting readiness for a roughly
125 ms row interval. Host tests cover that quantization case.
